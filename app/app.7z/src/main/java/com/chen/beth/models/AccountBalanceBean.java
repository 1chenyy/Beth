package com.chen.beth.models;

public class AccountBalanceBean {

    /**
     * status : 1
     * message : OK
     * result : 608539465893249898951277
     */

    public String status;
    public String message;
    public String result;
}
