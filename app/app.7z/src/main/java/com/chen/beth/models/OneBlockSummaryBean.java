package com.chen.beth.models;

public class OneBlockSummaryBean {

    /**
     * status : 1
     * result : {"number":8123036,"hash":"0x681befdefff6ee9f949a7887e28921165724c1295c01555e3253ae4d6be95d4f","time":1562755718,"txs":69,"miner":"0x5a0b54d5dc17e0aadc383d2db43b0a0d3e029c4c","reward":"2.0364804","unclereward":"0.0000000","difficult":"2193746147302820","totaldifficulty":"10953101594172021574755","size":12763,"gasused":2873278,"gaslimit":8008746,"extra":"PPYE sparkpool-eth-cn-hz3"}
     * error :
     */

    public int status;
    public BlockSummaryBean result;
    public String error;
}
