package com.chen.beth.searchfragment;

public class SearchHistoryDataBinding {
    public int type;
    public String content;

    public SearchHistoryDataBinding(int type, String content) {
        this.type = type;
        this.content = content;
    }
}
