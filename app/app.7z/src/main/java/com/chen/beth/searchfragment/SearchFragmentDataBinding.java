package com.chen.beth.searchfragment;

import androidx.databinding.Observable;
import androidx.databinding.ObservableBoolean;

public class SearchFragmentDataBinding {
    public ObservableBoolean hasHistory = new ObservableBoolean();
}
