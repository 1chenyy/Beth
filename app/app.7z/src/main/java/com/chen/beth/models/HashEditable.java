package com.chen.beth.models;

public interface HashEditable {
    void Updata(String... hash);
}
