package com.chen.beth.searchfragment;

public interface IPreLoad {
    void onPreLoad();
}
