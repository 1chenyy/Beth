package com.chen.beth.models;

public enum LoadingState {
    LODING,LOADING_SUCCEED,LOADING_FAILED,LOADING_NO_DATA
}
