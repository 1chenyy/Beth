package com.chen.beth.blockchainfragment;

import android.view.View;

import androidx.databinding.BindingAdapter;

import com.chen.beth.models.LoadingState;

public class BlockChainBindAdapter {


}
