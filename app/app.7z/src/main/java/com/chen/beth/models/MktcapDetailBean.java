package com.chen.beth.models;

import java.util.ArrayList;

public class MktcapDetailBean {
    public int status;
    public ArrayList<Double> result;
    public String error;
}
