package com.chen.beth.models;

public enum NetState {
    CONNECTED,DISCONNECTED,NONE
}
