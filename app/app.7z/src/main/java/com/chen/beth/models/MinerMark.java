package com.chen.beth.models;

public class MinerMark {
    public int id;
    public String hash;
    public MinerMark(){

    }

    public MinerMark(int id, String hash) {
        this.id = id;
        this.hash = hash;
    }
}
