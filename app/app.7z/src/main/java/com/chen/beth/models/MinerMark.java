package com.chen.beth.models;

public class MinerMark {
}
