package com.chen.beth.searchfragment;

import com.chen.beth.models.TransactionSummaryBean;

public class TransactionSummaryDataBinding {
    public String from;
    public String to;
    public String value;



}
