package com.chen.beth.models;

public enum SearchState {
    SEARCHING,SEARCH_SUCCEED,SEARCH_FAILED,SEARCH_NO_DATA
}
